<?php
require_once '../../includes/auth.php';
requireRole('admin');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $patient_id = $_POST['patient_id'];
    $caregiver_id = $_POST['caregiver_id'];
    $stmt = $conn->prepare("INSERT IGNORE INTO caregiver_patient (caregiver_id, patient_id) VALUES (?, ?)");
    $stmt->bind_param('ii', $caregiver_id, $patient_id);
    $stmt->execute();
    $message = "Assignment saved.";
}

$caregivers = $conn->query("SELECT id, full_name FROM users WHERE role='caregiver'")->fetch_all(MYSQLI_ASSOC);
$patients = getAllPatients();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign Caregivers</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include '../../includes/navbar.php'; ?>
    <div class="container mt-4">
        <h1>Assign Caregiver to Patient</h1>
        <?php if (isset($message)) echo "<div class='alert alert-success'>$message</div>"; ?>
        <form method="POST">
            <div class="mb-3">
                <label for="patient_id" class="form-label">Patient</label>
                <select class="form-control" id="patient_id" name="patient_id" required>
                    <option value="">Select Patient</option>
                    <?php foreach ($patients as $p): ?>
                    <option value="<?php echo $p['id']; ?>"><?php echo htmlspecialchars($p['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="caregiver_id" class="form-label">Caregiver</label>
                <select class="form-control" id="caregiver_id" name="caregiver_id" required>
                    <option value="">Select Caregiver</option>
                    <?php foreach ($caregivers as $c): ?>
                    <option value="<?php echo $c['id']; ?>"><?php echo htmlspecialchars($c['full_name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Assign</button>
        </form>
        <hr>
        <h3>Current Assignments</h3>
        <table class="table">
            <thead>
                <tr><th>Patient</th><th>Caregiver</th></tr>
            </thead>
            <tbody>
                <?php
                $assignments = $conn->query("
                    SELECT p.name as patient, u.full_name as caregiver
                    FROM caregiver_patient cp
                    JOIN patients p ON cp.patient_id = p.id
                    JOIN users u ON cp.caregiver_id = u.id
                    ORDER BY p.name
                ")->fetch_all(MYSQLI_ASSOC);
                foreach ($assignments as $a):
                ?>
                <tr><td><?php echo htmlspecialchars($a['patient']); ?></td><td><?php echo htmlspecialchars($a['caregiver']); ?></td></tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>