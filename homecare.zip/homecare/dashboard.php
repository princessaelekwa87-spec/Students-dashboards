<?php
require_once 'includes/auth.php';
requireLogin();

$role = $_SESSION['role'];
switch ($role) {
    case 'admin':
        header('Location: pages/admin/dashboard.php');
        break;
    case 'caregiver':
        header('Location: pages/caregiver/dashboard.php');
        break;
    case 'client':
        header('Location: pages/client/dashboard.php');
        break;
    default:
        header('Location: login.php');
}
exit;