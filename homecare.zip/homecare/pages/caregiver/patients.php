<?php
require_once '../../includes/auth.php';
requireRole('caregiver');

$caregiver_id = $_SESSION['user_id'];
$patients = getPatientsByCaregiver($caregiver_id);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Patients</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include '../../includes/navbar.php'; ?>
    <div class="container mt-4">
        <h1>My Assigned Patients</h1>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Address</th>
                    <th>Emergency Contact</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($patients as $p): ?>
                <tr>
                    <td><?php echo htmlspecialchars($p['name']); ?></td>
                    <td><?php echo $p['age']; ?></td>
                    <td><?php echo htmlspecialchars($p['address']); ?></td>
                    <td><?php echo htmlspecialchars($p['emergency_contact']); ?></td>
                    <td>
                        <a href="patient_view.php?id=<?php echo $p['id']; ?>" class="btn btn-sm btn-info">Details</a>
                        <a href="alerts.php?patient_id=<?php echo $p['id']; ?>" class="btn btn-sm btn-warning">Alerts</a>
                        <a href="medications.php?patient_id=<?php echo $p['id']; ?>" class="btn btn-sm btn-success">Medications</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>