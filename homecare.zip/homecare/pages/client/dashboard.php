<?php
require_once '../../includes/auth.php';
requireRole('client');

$user_id = $_SESSION['user_id'];
// Find patient record linked to this user
$stmt = $conn->prepare("SELECT * FROM patients WHERE user_id = ?");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$patient = $stmt->get_result()->fetch_assoc();

if (!$patient) {
    die("No patient record found for your account.");
}

$latest_sensor = getLatestSensorData($patient['id']);
$medications = getMedicationsForPatient($patient['id']);
$alerts = getAlerts($patient['id'], 5);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include '../../includes/navbar.php'; ?>
    <div class="container mt-4">
        <h1>Welcome, <?php echo htmlspecialchars($patient['name']); ?></h1>
        <div class="row">
            <div class="col-md-6">
                <div class="card mb-3">
                    <div class="card-header">Today's Health Snapshot</div>
                    <div class="card-body">
                        <?php if (count($latest_sensor) > 0): ?>
                        <ul class="list-group">
                            <?php foreach ($latest_sensor as $s): ?>
                            <li class="list-group-item"><?php echo $s['sensor_type']; ?>: <?php echo $s['value'] . ' ' . $s['unit']; ?></li>
                            <?php endforeach; ?>
                        </ul>
                        <?php else: ?>
                        <p>No recent sensor data.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card mb-3">
                    <div class="card-header">Medication Reminders</div>
                    <div class="card-body">
                        <?php if (count($medications) > 0): ?>
                        <ul class="list-group">
                            <?php foreach ($medications as $m): ?>
                            <li class="list-group-item">
                                <?php echo $m['name'] . ' ' . $m['dosage']; ?> - Next: <?php echo $m['next_due']; ?>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                        <?php else: ?>
                        <p>No medications scheduled.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Recent Alerts</div>
                    <div class="card-body">
                        <?php if (count($alerts) > 0): ?>
                        <ul class="list-group">
                            <?php foreach ($alerts as $a): ?>
                            <li class="list-group-item"><?php echo $a['type'] . ': ' . $a['message']; ?> (<?php echo $a['created_at']; ?>)</li>
                            <?php endforeach; ?>
                        </ul>
                        <?php else: ?>
                        <p>No alerts.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>